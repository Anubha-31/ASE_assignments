package solutionASE;

public class Chrysalis {
	String state;

	public Chrysalis(String state) {
		super();
		this.state = state;
	}
	
	public void metamorphis() {
		System.out.println("the process of metamorphis goes on for about 10 days");
		System.out.println("it is a process where old body parts of catterpillar goes extensive changes\n"
				+ "to new body parts of butterfly");
		System.out.println("\n....After 10 days");
		System.out.println("Butterfly has emerged!!");
	}

}
