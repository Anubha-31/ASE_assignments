package solutionASE;

public abstract class Insect {

	protected int eyes;
	
	protected int legs;
	
	protected int wings;

	public abstract int getEyes();

	public abstract int getLegs();

	public abstract int getWings();

	
	
}
